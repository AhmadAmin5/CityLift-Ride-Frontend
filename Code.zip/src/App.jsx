import { Navigate, Route, Routes } from "react-router-dom";

import SplashPage from "@/pages/SplashPage";
import LoginPage from "@/pages/auth/LoginPage";
import RegisterPage from "@/pages/auth/RegisterPage";
import OtpVerificationPage from "@/pages/auth/OtpVerificationPage";
import PlaceholderPage from "@/pages/PlaceholderPage";
import { PublicOnlyRoute, RequireAuth } from "@/routes/AuthGuards";
import RiderHomePage from "@/pages/rider/RiderHomePage";
import RiderRideConfirmPage from "@/pages/rider/RiderRideConfirmPage";
import RiderSearchingPage from "@/pages/rider/RiderSearchingPage";
import RiderLiveRidePage from "./pages/rider/RiderLiveRidePage";
import RiderReceiptPage from "./pages/rider/RiderReceiptPage";
import RiderRatingPage from "./pages/rider/RiderRatingPage";
import RiderRideHistoryPage from "./pages/rider/RiderRideHistoryPage";
import RiderRideDetailPage from "./pages/rider/RiderRideDetailPage";
import RiderSavedPlacesPage from "./pages/rider/RiderSavedPlacesPage";
import ProfilePage from "./pages/shared/ProfilePage";
import DriverHomePage from "./pages/driver/DriverHomePage";
import DriverOnboardingPage from "./pages/driver/DriverOnboardingPage";
import DriverDocumentsPage from "./pages/driver/DriverDocumentsPage";
import DriverVehiclesPage from "./pages/driver/DriverVehiclesPage";
import DriverNavigationToPickupPage from "./pages/driver/DriverNavigationToPickupPage";
import DriverArrivedWaitingPage from "./pages/driver/DriverArrivedWaitingPage";
import DriverActiveTripPage from "./pages/driver/DriverActiveTripPage";
import DriverRideSummaryPage from "./pages/driver/DriverRideSummaryPage";
import DriverEarningsPage from "./pages/driver/DriverEarningsPage";
import DriverRatingsPage from "./pages/driver/DriverRatingsPage";
import AdminDashboardPage from "./pages/admin/AdminDashboardPage";
import AdminPricingRulesPage from "./pages/admin/AdminPricingRulesPage";
import AdminDriverDocumentsPage from "./pages/admin/AdminDriverDocumentsPage";
import AdminSurgeZonesPage from "./pages/admin/AdminSurgeZonesPage";
import AdminVehicleVerificationPage from "./pages/admin/AdminVehicleVerificationPage";
import AdminGraphAnalyticsPage from "./pages/admin/AdminGraphAnalyticsPage";
import BackButtonHandler from "@/components/navigation/BackButtonHandler";

export default function App() {
    return (
        <>
            <BackButtonHandler />
            <Routes>
            <Route path="/" element={<Navigate to="/splash" replace />} />
            <Route path="/splash" element={<SplashPage />} />

            <Route element={<PublicOnlyRoute />}>
                <Route path="/auth/login" element={<LoginPage />} />
                <Route
                    path="/auth/register/rider"
                    element={<RegisterPage role="rider" />}
                />
                <Route
                    path="/auth/register/driver"
                    element={<RegisterPage role="driver" />}
                />
            </Route>

            <Route path="/auth/verify-otp" element={<OtpVerificationPage />} />
            <Route path="/auth/otp" element={<OtpVerificationPage />} />

            <Route element={<RequireAuth allowedRoles={["rider"]} />}>
                <Route path="/rider/home" element={<RiderHomePage />} />
                <Route
                    path="/rider/ride/confirm"
                    element={<RiderRideConfirmPage />}
                />
                <Route
                    path="/rider/ride/:ride_id/searching"
                    element={<RiderSearchingPage />}
                />
                <Route
                    path="/rider/ride/:ride_id/live"
                    element={<RiderLiveRidePage />}
                />
                <Route
                    path="/rider/rides/:ride_id"
                    element={<RiderRideDetailPage />}
                />
                <Route
                    path="/rider/saved-places"
                    element={<RiderSavedPlacesPage />}
                />
                <Route
                    path="/rider/ride/:ride_id/receipt"
                    element={<RiderReceiptPage />}
                />
                <Route
                    path="/rider/ride/:ride_id/rating"
                    element={<RiderRatingPage />}
                />
                <Route path="/rider/rides" element={<RiderRideHistoryPage />} />
                <Route path="/rider/profile" element={<ProfilePage />} />
            </Route>

            <Route
                element={
                    <RequireAuth allowedRoles={["rider", "driver", "admin"]} />
                }
            >
                <Route path="/profile" element={<ProfilePage />} />
            </Route>

            <Route element={<RequireAuth allowedRoles={["driver"]} />}>
                <Route path="/driver/home" element={<DriverHomePage />} />
                <Route
                    path="/driver/onboarding"
                    element={<DriverOnboardingPage />}
                />
                <Route
                    path="/driver/documents"
                    element={<DriverDocumentsPage />}
                />
                <Route
                    path="/driver/vehicles"
                    element={<DriverVehiclesPage />}
                />
                <Route path="/driver/ratings" element={<DriverRatingsPage />} />
                <Route
                    path="/driver/rides/:ride_id/navigation"
                    element={<DriverNavigationToPickupPage />}
                />
                <Route
                    path="/driver/ride/:ride_id/to-pickup"
                    element={<DriverNavigationToPickupPage />}
                />
                <Route
                    path="/driver/rides/:ride_id/arrived"
                    element={<DriverArrivedWaitingPage />}
                />
                <Route
                    path="/driver/ride/:ride_id/arrived"
                    element={<DriverArrivedWaitingPage />}
                />
                <Route
                    path="/driver/rides/:ride_id/active"
                    element={<DriverActiveTripPage />}
                />
                <Route
                    path="/driver/ride/:ride_id/active"
                    element={<DriverActiveTripPage />}
                />
                <Route
                    path="/driver/rides/:ride_id/summary"
                    element={<DriverRideSummaryPage />}
                />
                <Route
                    path="/driver/ride/:ride_id/summary"
                    element={<DriverRideSummaryPage />}
                />
                <Route path="/driver/earnings" element={<DriverEarningsPage />} />
            </Route>

            <Route element={<RequireAuth allowedRoles={["admin"]} />}>
                <Route
                    path="/admin/dashboard"
                    element={<AdminDashboardPage />}
                />
                <Route
                    path="/admin/pricing-rules"
                    element={<AdminPricingRulesPage />}
                />
                <Route
                    path="/admin/driver-documents"
                    element={<AdminDriverDocumentsPage />}
                />
                <Route
                    path="/admin/surge-zones"
                    element={<AdminSurgeZonesPage />}
                />
                <Route
                    path="/admin/vehicle-verification"
                    element={<AdminVehicleVerificationPage />}
                />
                <Route
                    path="/admin/ml-models"
                    element={<PlaceholderPage title="ML Models" />}
                />
                <Route
                    path="/admin/graph-analytics"
                    element={<AdminGraphAnalyticsPage />}
                />
            </Route>

            <Route path="*" element={<Navigate to="/splash" replace />} />
        </Routes>
        </>
    );
}